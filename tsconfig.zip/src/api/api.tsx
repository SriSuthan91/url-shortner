const api_url = "http://localhost:3001/urls/";

export default api_url;